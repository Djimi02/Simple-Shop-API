package com.example.simple_shop;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SimpleShopApplicationTests {

	@Test
	void contextLoads() {
	}

}
